package V4.Smoke.enrollment.applibs;

import core.libs.Browser;
import core.libs.FileIO;
import core.libs.Log;
import core.libs.Platform;

public class CommonLogin 
{

public static void CommonLogin_Run() throws InterruptedException
{
		
	
	

	Log.gsScriptName = Thread.currentThread().getStackTrace()[1].getClassName();  //this.getClass().getName().toString();
	Log.gsScriptDescription = "Test and verify Clientconsole Login Page";
	Log.gsScriptAuthor = "archana enturu";
	Log.gsScriptTestArea = FileIO.getParentPath(Platform.getCurrentProjectPath() + Log.gsScriptName.replace(".",Platform.getFileSeparator()));

	//LoginPage.loadGoogleProperties();
	Log.initialize();

	Erm_Login_Page.ccClientConsoleproperties(); //loads google global properties from google.properties file
	//	System.out.println("the string is===="+Log.gsAutomationAutoSupportDocs);
	//	Baseclass.otplogin();


	Log.logBanner("Setup for CLIENTCONSOLE Testcases");
	//Browser.start();
	//System.out.println("url is===="+LoginPage.gsGoogleURL);
	//String path= Platform.getCurrentProjectPath();
	//System.out.println("path is ====="+LoginPage.gsGooglePropertiesFile);

	//	LoginPage.loadGoogleProperties();
	//load Google page and wait for search button to appear
	//Browser.loadURL(LoginPage.gsGoogleURL,Log.giAutomationShortTO);
	//
	
	Browser.start();

	
	
	Browser.loadURL(Erm_Login_Page.EnrollmentUrl,Log.giAutomationShortTO);
	Thread.sleep(2000);
	Erm_Login_Page.erm_UserName("ramhippa");

	Erm_Login_Page.erm_Password("668iugsE");
	Erm_Login_Page.Submit();
	Thread.sleep(2000); 
	}

	public static void Common_Link()
	{
		Erm_AccountSummary_Page.clilk_on_AcntSumry();
	}
	public static void Common_logout()
	{
		Erm_AccountSummary_Page.click_on_logout();
	}

}