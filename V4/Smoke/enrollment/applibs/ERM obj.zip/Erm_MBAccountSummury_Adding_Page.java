package V4.Smoke.enrollment.applibs;

import core.webwidgets.*;

public class Erm_MBAccountSummury_Adding_Page 
{
	/**
	 * TextField object for "ManageBillingAccount_NickName" Object Class Type Not found with locator of "name='billingAccount.accountNickname"
	 * @return web UI TextField object for the "ManageBillingAccount_NickName" Object Class Type Not found with locator of "name=billingAccount.accountNickname"
	 */
	public static TextField ManageBillingAccount_Account_Num()
	{
		return new TextField("name=billingAccount.billingAccountNumber");
	}
	public static void Enter_Account_Num(String s)
	{
		ManageBillingAccount_Account_Num().setText(s);
	}
	
	/**
	 * TextField object for "ManageBillingAccount_NickName" Object Class Type Not found with locator of "name='billingAccount.accountNickname"
	 * @return web UI TextField object for the "ManageBillingAccount_NickName" Object Class Type Not found with locator of "name=billingAccount.accountNickname"
	 */
	/**public static TextField ManageBillingAccount_SecurityKey_Ac_Info()
	{
		return new TextField("name=loginFields[0]");
	}
	public static void Enter_Security_Num(String s)
	{
		ManageBillingAccount_SecurityKey_Ac_Info().setText(s);
	}**/
	/**
	 * ListBox object for "PayYourBillNow_DropDown_CreditCardState" ListBox with locator of "name=creditCardAccount.accountState"
	 * @return web UI ListBox object for the "PayYourBillNow_DropDown_CreditCardState" ListBox with locator of "name=creditCardAccount.accountState"
	 */
	public static ListBox ManageBillingAccount_DropDown_Divison() 
	{
		return new ListBox("name=billingAccount.divisionBusinessId");
	}
	public static void select_Division(String s)
	{
		ManageBillingAccount_DropDown_Divison().selectItem(s);
	}
	/**
	* Object Class Type Not found object for "ManageBillingAccount_CheckBox_paperbill_1" Object Class Type Not found with locator of "@name=$fieldName_cb"
	* @return web UI Object Class Type Not found object for the "ManageBillingAccount_CheckBox_paperbill_1" Object Class Type Not found with locator of "name=$fieldName_cb"
	*/
	public static CheckBox ManageBillingAccount_CheckBox_paperbill()
	{
		return new CheckBox("name=billingAccount.paperBill");
	}
	public static void click_CheckBox()
	{
		ManageBillingAccount_CheckBox_paperbill().check();
	}
}
