package V4.Smoke.enrollment.applibs;

import core.webwidgets.*;

public class Erm_SingUp_Page 
{
	
	   /** TextField object for "SingUp_TextBox_Acntnum" TextField with locator of ("name=billingAccountNumber")
	    * @return web UI TextField object for the "SingUp_TextBox_Acntnum" TextField with locator of ("name=billingAccountNumber")
	    */
	   public static TextField SingUp_TextBox_Acntnum()
	   {
		return new TextField("name=billingAccountNumber");
	    }
	   public static void Enter_Account_Num(String s)
		{
		   SingUp_TextBox_Acntnum().setText(s);
		}
	   
	   /**
	    * TextField object for "SingUp_TextBox_UserName" TextField with locator of ("name=consumerProfile.username")
	    * @return web UI TextField object for the "SingUp_TextBox_UserName" TextField with locator of ("name=consumerProfile.username")
	    */
	   public static TextField SingUp_TextBox_UserName()
	   {
		return new TextField("name=consumerProfile.username");
	    }
	   public static void Enter_UserName(String s)
		{
		   SingUp_TextBox_UserName().setText(s);
		}
	    /**
	    * TextField object for "SingUp_TextBox_Retype_UserName" TextField with locator of ("name=confirmUserName")
	    * @return web UI TextField object for the "SingUp_TextBox_Retype_UserName" TextField with locator of ("name=confirmUserName")
	    */
	   public static TextField SingUp_TextBox_Retype_UserName()
	   {
		return new TextField("name=confirmUserName");
	    }
	   public static void Enter_Retype_UserName(String s)
		{
		   SingUp_TextBox_Retype_UserName().setText(s);
		}
	   /**
	    * TextField object for "SingUp_TextBox_Password" TextField with locator of ("name=consumerProfile.password")
	    * @return web UI TextField object for the "SingUp_TextBox_Password" TextField with locator of ("name=consumerProfile.password")
	    */
	   public static TextField SingUp_TextBox_Password()
	   {
		return new TextField("name=consumerProfile.password");
	    }
	   public static void Enter_Password(String s)
		{
		   SingUp_TextBox_Password().setText(s);
		}
	  /**
	    * TextField object for "SingUp_TextBox_ConPassword" TextField with locator of ("name=confirmPassword")
	    * @return web UI TextField object for the "SingUp_TextBox_ConPassword" TextField with locator of ("name=confirmPassword")
	    */
	   public static TextField SingUp_TextBox_ConPassword()
	   {
		return new TextField("name=confirmPassword");
	    }
	   public static void Enter_ConPassword(String s)
		{
		   SingUp_TextBox_ConPassword().setText(s);
		}

}
