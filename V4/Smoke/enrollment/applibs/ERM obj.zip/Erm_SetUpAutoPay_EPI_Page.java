package V4.Smoke.enrollment.applibs;

import core.webwidgets.RadioButton;

public class Erm_SetUpAutoPay_EPI_Page
{

/**
* RadioButton object for "SetupAutoPay_Radio_Mnthly" RadioButton with locator of "//*[@value='MONTHLY']"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_Mnthly" RadioButton with locator of "//*[@value='MONTHLY']"
*/
public static RadioButton SetupAutoPay_Radio_Mnthly() {
	return new RadioButton("id=MONTHLY");
}


/**
* RadioButton object for "SetupAutoPay_Radio_BiWeekly" RadioButton with locator of "id=BIWEEKLY"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_BiWeekly" RadioButton with locator of "id=BIWEEKLY"
*/
public static RadioButton SetupAutoPay_Radio_BiWeekly() {
	return new RadioButton("id=BIWEEKLY");
}


/**
* RadioButton object for "SetupAutoPay_Radio_Weekly" RadioButton with locator of "id="WEEKLY"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_Weekly" RadioButton with locator of "id=WEEKLY"
*/
public static RadioButton SetupAutoPay_Radio_Weekly() {
	return new RadioButton("id=WEEKLY");
}
/**
* RadioButton object for "SetupAutoPay_Radio_PerBilingCycle" RadioButton with locator of "id=PERBILLINGCYCLE"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_PerBilingCycle" RadioButton with locator of "id=PERBILLINGCYCLE"
*/
public static RadioButton SetupAutoPay_Radio_PerBilingCycle() {
	return new RadioButton("id=PERBILLINGCYCLE");
}

/**
* RadioButton object for "SetupAutoPay_Radio_SemiMnthlyDayv" RadioButton with locator of "id=SEMI-MONTHLYDAYS"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_SemiMnthlyDayv" RadioButton with locator of "id=SEMI-MONTHLYDAYS"
*/
public static RadioButton SetupAutoPay_Radio_SemiMnthlyDayv() {
	return new RadioButton("id=SEMI-MONTHLYDAYS");
}


/**
* RadioButton object for "SetupAutoPay_Radio_SemiMnthly" RadioButton with locator of "id=SEMI-MONTHLY"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_SemiMnthly" RadioButton with locator of "id=SEMI-MONTHLY"
*/
public static RadioButton SetupAutoPay_Radio_SemiMnthly() {
	return new RadioButton("id=SEMI-MONTHLY");
}


/**
* RadioButton object for "SetupAutoPay_Radio_UponRecipt" RadioButton with locator of "id=UPONRECEIPT"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_UponRecipt" RadioButton with locator of "id=UPONRECEIPT"
*/
public static RadioButton SetupAutoPay_Radio_UponRecipt() {
	return new RadioButton("id=UPONRECEIPT");
}
/**
* RadioButton object for "SetupAutoPay_Radio_FixedDate" RadioButton with locator of "//*[@value='DAY OF MONTH']"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_FixedDate" RadioButton with locator of "//*[@value='DAY OF MONTH']"
*/
public static RadioButton SetupAutoPay_Radio_FixedDate() {
	return new RadioButton("//*[@value='DAY OF MONTH']");
}


/**
* RadioButton object for "SetupAutoPay_Radio_FixedWeek" RadioButton with locator of "//*[@value='DAY OF WEEK']"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_FixedWeek" RadioButton with locator of "//*[@value='DAY OF WEEK']"
*/
public static RadioButton SetupAutoPay_Radio_FixedWeek() {
	return new RadioButton("//*[@value='DAY OF WEEK']");
}


/**
* RadioButton object for "SetupAutoPay_Radio_DayBeforeDueDate" RadioButton with locator of "//*[@value='DAYS BEFORE DUE DATE']"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_DayBeforeDueDate" RadioButton with locator of "//*[@value='DAYS BEFORE DUE DATE']"
*/
public static RadioButton SetupAutoPay_Radio_DayBeforeDueDate() {
	return new RadioButton("//*[@value='DAYS BEFORE DUE DATE']");
}


/**
* RadioButton object for "SetupAutoPay_Radio_DueDate" RadioButton with locator of "//*[@value='DUE DATE']"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_DueDate" RadioButton with locator of "//*[@value='DUE DATE']"
*/
public static RadioButton SetupAutoPay_Radio_DueDate() {
	return new RadioButton("//*[@value='DUE DATE']");
}


/**
* RadioButton object for "SetupAutoPay_Radio_SemiMnthlyDayst" RadioButton with locator of "//*[@title='SEMI-MONTHLY DAYS']"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_SemiMnthlyDayst" RadioButton with locator of "//*[@title='SEMI-MONTHLY DAYS']"
*/
public static RadioButton SetupAutoPay_Radio_SemiMnthlyDayst() {
	return new RadioButton("//*[@title='SEMI-MONTHLY DAYS']");
}


/**
* RadioButton object for "SetupAutoPay_Radio_UponRecpt" RadioButton with locator of "//*[@value='UPON RECEIPT']"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_UponRecpt" RadioButton with locator of "//*[@value='UPON RECEIPT']"
*/
public static RadioButton SetupAutoPay_Radio_UponRecpt() {
	return new RadioButton("//*[@value='UPON RECEIPT']");
}


/**
* RadioButton object for "SetupAutoPay_Radio_AmtDue" RadioButton with locator of "//*[@value='AMOUNT DUE']"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_AmtDue" RadioButton with locator of "//*[@value='AMOUNT DUE']"
*/
public static RadioButton SetupAutoPay_Radio_AmtDue() {
	return new RadioButton("id=amount_due");
}


/**
* RadioButton object for "SetupAutoPay_Radio_AmtDueUpto" RadioButton with locator of "//*[@value='AMOUNT DUE THRESHOLD']"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_AmtDueUpto" RadioButton with locator of "//*[@value='AMOUNT DUE THRESHOLD']"
*/
public static RadioButton SetupAutoPay_Radio_AmtDueUpto() {
	return new RadioButton("id=amount_due_upto");
}


/**
* RadioButton object for "SetupAutoPay_Radio_FixedAmt" RadioButton with locator of "//*[@value='FIXED AMOUNT']"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_FixedAmt" RadioButton with locator of "//*[@value='FIXED AMOUNT']"
*/
public static RadioButton SetupAutoPay_Radio_FixedAmt() {
	return new RadioButton("id=fixed_amount");
}
/**
* RadioButton object for "SetupAutoPay_Radio_UntilCancelled" RadioButton with locator of "//*[@value='UNTIL CANCELLED']"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_UntilCancelled" RadioButton with locator of "//*[@value='UNTIL CANCELLED']"
*/
public static RadioButton SetupAutoPay_Radio_UntilCancelled() {
	return new RadioButton("id=UNTILCANCELLED");
}


/**
* RadioButton object for "SetupAutoPay_Radio_UntilSuspendDate" RadioButton with locator of "//*[@value='UNTIL SUSPEND DATE']"
* @return web UI RadioButton object for the "SetupAutoPay_Radio_UntilSuspendDate" RadioButton with locator of "//*[@value='UNTIL SUSPEND DATE']"
*/
public static RadioButton SetupAutoPay_Radio_UntilSuspendDate() {
	return new RadioButton(" id=UNTILSUSPENDDATE");
}

























}
