package V4.Smoke.enrollment.applibs;

import core.webwidgets.ListBox;
import core.webwidgets.TextField;

public class Erm_ManagePaymentMethod_Add_A_CC 
{
	/**
	 * ListBox object for "PayYourBillNow_DropDown_CreditCardType" ListBox with locator of "name=creditCardAccount.creditCardType"
	 * @return web UI ListBox object for the "PayYourBillNow_DropDown_CreditCardType" ListBox with locator of "name=creditCardAccount.creditCardType"
	 */
	public static ListBox ManagePaymentMethod_CreditCardType() 
	{
		return new ListBox("name=creditCardAccount.creditCardType");
	}
	public static void select_CreditCardType(String s)
	{
		ManagePaymentMethod_CreditCardType().selectItem(s);
	}
	/**
	 * TextField object for "PayYourBillow_TextBox_CardCvvo" TextField with locator of ("name=creditCardAccount.securityCode")
	 * @return web UI TextField object for the "PayYourBillow_TextBox_CardCvv" TextField with locator of ("name=creditCardAccount.securityCode")
	 */
	public static TextField ManagePaymentMethod_CardCvv()
	{
		return new TextField("name=creditCardAccount.securityCode");
	}
	public static void Enter_CardCvv(String s)
	{
		ManagePaymentMethod_CardCvv().setText(s);
	}
	/**
	 * ListBox object for "PayYourBillNow_DropDown_CreditCardType" ListBox with locator of "name=creditCardAccount.creditCardType"
	 * @return web UI ListBox object for the "PayYourBillNow_DropDown_CreditCardType" ListBox with locator of "name=creditCardAccount.creditCardType"
	 */
	public static ListBox ManagePaymentMethod_DropDown_CreditCardExp_Month() 
	{
		return new ListBox("name=creditCardAccount.expirationMonth");
	}
	public static void select_CreditCardExp_Month(String s)
	{
		ManagePaymentMethod_DropDown_CreditCardExp_Month().selectItem(s);
	}

	/**
	 * ListBox object for "PayYourBillNow_DropDown_CreditCardExp_Year" ListBox with locator of "name=creditCardAccount.expirationYear"
	 * @return web UI ListBox object for the "PayYourBillNow_DropDown_CreditCardExp_Year" ListBox with locator of "name=creditCardAccount.expirationYear"
	 */
	public static ListBox ManagePaymentMethod_DropDown_CreditCardExp_Year() 
	{
		return new ListBox("name=creditCardAccount.expirationYear");
	}
	public static void select_CreditCardExp_Year(String s)
	{
		ManagePaymentMethod_DropDown_CreditCardExp_Year().selectItem(s);
	}
}
