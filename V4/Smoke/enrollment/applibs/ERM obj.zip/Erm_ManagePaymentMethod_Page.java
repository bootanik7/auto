package V4.Smoke.enrollment.applibs;


import core.webwidgets.*;


public class Erm_ManagePaymentMethod_Page {
	/**
	* Link object for "ManagePaymentMethods_Link_DeleteFunding" Link with locator of "link=Delete Funding"
	* @return web UI Link object for the "ManagePaymentMethods_Link_DeleteFunding" Link with locator of "link=Delete Funding"
	*/
	public static Link ManagePaymentMethods_Link_DeleteFunding()
	{
		return new Link("link=Delete Funding");
	}
	public static void click_on_Delete()
	{
		 ManagePaymentMethods_Link_DeleteFunding().click();
	}

	/**
	 * TextField object for " ManagePaymentMethods_TextBox_CustAdd1" TextField with locator of ("name=fundingAccount.accountAddress1")
	 * @return web UI TextField object for the " ManagePaymentMethods_TextBox_CustAdd1" TextField with locator of ("name=fundingAccount.accountAddress1")
	 */
	public static TextField ManagePaymentMethods_CustAdd1()
	{
		return new TextField("name=fundingAccount.accountAddress1");
	}

	/**
	 * TextField object for " ManagePaymentMethods_TextBox_CustAdd2" TextField with locator of ("name=fundingAccount.accountAddress2")
	 * @return web UI TextField object for the "PayYourBillow_TextBox_CustAdd2" TextField with locator of ("name=fundingAccount.accountAddress2")
	 */
	public static TextField ManagePaymentMethods_CustAdd2()
	{
		return new TextField("name=fundingAccount.accountAddress2");
	}
	/**
	 * TextField object for " ManagePaymentMethods_TextBox_CustAdd2" TextField with locator of ("name=fundingAccount.accountCity")
	 * @return web UI TextField object for the "PayYourBillow_TextBox_CustAdd2" TextField with locator of ("name=fundingAccount.accountCity")
	 */
	public static TextField ManagePaymentMethods_City()
	{
		return new TextField("name=fundingAccount.accountCity");
	}
	/**
	 * ListBox object for " ManagePaymentMethods_DropDown_CreditCardState" ListBox with locator of ("name=fundingAccount.accountState")
	 * @return web UI ListBox object for the "PayYourBillNow_DropDown_CreditCardState" ListBox with locator of ("name=fundingAccount.accountState")
	 */
	public static ListBox  ManagePaymentMethods_DropDown_CreditCardState() 
	{
		return new ListBox("name=fundingAccount.accountState");
	}
	/**
	 * TextField object for " ManagePaymentMethods_TextBox_Zipcode" TextField with locator of ("name=fundingAccount.accountPostalCode")
	 * @return web UI TextField object for the "PayYourBillow_TextBox_Zipcode" TextField with locator of ("name=fundingAccount.accountPostalCode")
	 */
	public static TextField  ManagePaymentMethods_Zipcode()
	{
		return new TextField("name=fundingAccount.accountPostalCode");
	}
	
	/**
	 * ListBox object for " ManagePaymentMethods_DropDown_Country" ListBox with locator of ("name=fundingAccount.accountCountryCode")
	 * @return web UI ListBox object for the "PayYourBillNow_DropDown_Country" ListBox with locator of ("name=fundingAccount.accountCountryCode")
	 */
	public static ListBox  ManagePaymentMethods_DropDown_Country() 
	{
		return new ListBox("name=fundingAccount.accountCountryCode");
	}
	/**
	* Link object for "ManagePaymentMethods_Link_Addbankacc" Link with locator of "link=Add A Bank Account"
	* @return web UI Link object for the "ManagePaymentMethods_Link_Addbankacc" Link with locator of "link=Add A Bank Account"
	*/
	public static Link ManagePaymentMethods_Link_AddBankAc()
	{
		return new Link("link=Add A Bank Account");
	}
	public static void click_on_AddBackAcc()
	{
		ManagePaymentMethods_Link_AddBankAc().click();
	}


	/**
	* Link object for "ManagePaymentMethods_Link_AddCard" Link with locator of "link=Add A Card"
	* @return web UI Link object for the "ManagePaymentMethods_Link_AddCard" Link with locator of "link=Add A Card"
	*/
	public static Link ManagePaymentMethods_Link_AddCard() {
		return new Link("link=Add A Card");
	}
	public static void click_on_AddCard()
	{
		 ManagePaymentMethods_Link_AddCard().click();
	}
	
	public static Button ManagePaymentMethods_Button_Update()
	{
		return new Button(".//*[@value='Update']");
	}
	public static void click_on_Update()
	{
		 ManagePaymentMethods_Button_Update().click();
	}
	
	public static StaticText ManagePaymentMethods_CNF1_Text()
	{
		 return new StaticText("//*[contains(text(),'Funding account has been modified successfully')]");
	}
	public static String get_CNF1_text()
	{
		String S=ManagePaymentMethods_CNF1_Text().getText();
		return S;
	}
	
	
	
	
	
		
	
}
