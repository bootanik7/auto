package V4.Smoke.enrollment.applibs;

import core.webwidgets.Link;

public class Erm_ModifyYourAutoPay_Page
{
	/**
	 * Link object for "ManagePersonalInfo_Link_Opt_In_Instructions" Link with locator of "link=Opt In Instructions"
	 * @return web UI Link object for the "ManagePersonalInfo_Link_Opt_In_Instructions" Link with locator of "link=Opt In Instructions"
	 */
	public static Link ManagePersonalInfo_Link_Discontinue_this_payment_schedule() 
	{
		return new Link("link=Discontinue this payment schedule");
	}
	
	
}
